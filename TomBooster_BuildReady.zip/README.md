# TomBooster V1

Android MVP for a Game Performance & Network Booster.

## Included
- Dark gaming dashboard
- TomBooster branding
- BOOST NOW interaction
- RAM usage reading
- Basic network latency check
- Network / Performance / Games / Settings dashboard cards
- Sample game profiles

## Important
This first version is a real Android project, but it deliberately does not claim to magically reduce server-side lag.
Android restricts many system-level optimizations for third-party apps. Future versions can add legitimate features such as:
- per-game profiles
- DNS configuration through supported Android mechanisms
- more accurate network diagnostics
- foreground gaming mode
- thermal/performance monitoring
- user-approved system settings shortcuts

Open the project in Android Studio and run it on an Android 8.0+ device/emulator.


## Gaming Mode (V2)
- One-tap Gaming Mode toggle from the Performance card.
- Keeps the screen awake while Gaming Mode is active.
- Uses Android immersive mode to hide navigation/status UI while active.
- Shows an in-app status indicating Gaming Mode is active.
- Does not falsely claim to kill apps, overclock the CPU, or bypass Android restrictions.
