# Build TomBooster online

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. Create a new GitHub repository.
2. Upload all files/folders from this project to the repository.
3. Open **Actions** -> **Build TomBooster APK**.
4. Click **Run workflow** (or push to `main`).
5. When the job finishes, open the run and download the artifact **TomBooster-debug-apk**.
6. Extract the ZIP to get `app-debug.apk` and install it on Android.

The workflow installs JDK 17 and Gradle 8.7 automatically, so Android Studio is not required on your PC.
