package com.tombooster.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Debug;
import android.os.Handler;
import android.os.Looper;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    DashboardView dashboard;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,10,18));
        getWindow().setNavigationBarColor(Color.rgb(5,10,18));
        dashboard = new DashboardView(this);
        setContentView(dashboard);
        dashboard.refreshNetwork();
    }

    class DashboardView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        Handler handler = new Handler(Looper.getMainLooper());
        ExecutorService executor = Executors.newSingleThreadExecutor();
        int ping = -1;
        int ram = 0;
        int cpu = 0;
        boolean boosting = false;
        boolean gamingMode = false;
        float pulse = 0f;

        DashboardView(Context c) {
            super(c);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(3);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            handler.post(tick);
        }

        Runnable tick = new Runnable() {
            public void run() {
                pulse += 0.035f;
                invalidate();
                handler.postDelayed(this, 33);
            }
        };

        void text(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setTextSize(size);
            p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
            c.drawText(s, x, y, p);
        }

        void rounded(Canvas c, float l, float t, float r, float b, float radius, int color) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            c.drawRoundRect(l,t,r,b,radius,radius,p);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            c.drawColor(Color.rgb(5,10,18));

            // Header
            text(c, "T", 28, 52, 38, Color.rgb(0,180,255), true);
            text(c, "TomBooster", 66, 50, 28, Color.WHITE, true);
            text(c, "GAME PERFORMANCE", 68, 73, 12, Color.rgb(120,190,235), false);

            rounded(c, w-104, 24, w-22, 58, 18, Color.rgb(12,24,38));
            text(c, "PRO", w-82, 46, 13, Color.rgb(255,190,40), true);

            // Hero
            float cx = w/2f, cy = 205;
            float rad = Math.min(w*0.31f, 135);
            stroke.setColor(Color.rgb(0,185,255));
            stroke.setStrokeWidth(8);
            c.drawCircle(cx, cy, rad + (float)Math.sin(pulse)*3, stroke);
            stroke.setColor(Color.rgb(0,85,150));
            stroke.setStrokeWidth(2);
            c.drawCircle(cx, cy, rad+18, stroke);
            rounded(c, cx-rad+12, cy-rad+12, cx+rad-12, cy+rad-12, rad, Color.rgb(7,24,43));

            text(c, boosting ? "BOOSTING..." : "BOOST NOW", cx-72, cy+5, 23, Color.WHITE, true);
            text(c, boosting ? "Optimizing..." : "Optimize your device", cx-73, cy+29, 12, Color.rgb(130,190,230), false);

            // Metrics card
            float mt = 350;
            rounded(c, 18, mt, w-18, mt+155, 22, Color.rgb(8,20,34));
            metric(c, "PING", ping < 0 ? "--" : ping+" ms", 35, mt+42);
            metric(c, "JITTER", "—", w/2f-40, mt+42);
            metric(c, "PACKET LOSS", "—", w-135, mt+42);
            metric(c, "RAM", ram+"%", 35, mt+112);
            metric(c, "CPU", cpu+"%", w/2f-40, mt+112);
            metric(c, "TEMP", "—", w-135, mt+112);

            // Shortcut cards
            float top = mt+175, gap=10, cw=(w-36-gap*3)/4f;
            card(c, 18, top, cw, "Network", "DNS • Ping", Color.rgb(0,185,255));
            card(c, 18+cw+gap, top, cw, gamingMode ? "Gaming ON" : "Gaming Mode", gamingMode ? "Active • Screen On" : "Tap to enable", Color.rgb(150,80,255));
            card(c, 18+(cw+gap)*2, top, cw, "My Games", "Profiles", Color.rgb(20,220,130));
            card(c, 18+(cw+gap)*3, top, cw, "Settings", "Options", Color.LTGRAY);

            // Games
            float gy = top+120;
            text(c, "My Games", 22, gy, 20, Color.WHITE, true);
            text(c, "View All  ›", w-95, gy, 13, Color.rgb(110,160,195), false);
            game(c, 18, gy+18, "PUBG MOBILE", Color.rgb(20,220,130));
            game(c, 155, gy+18, "CALL OF DUTY", Color.rgb(20,220,130));
            game(c, 292, gy+18, "FREE FIRE", Color.rgb(20,220,130));

            // Status
            rounded(c, 18, h-82, w-18, h-32, 24, Color.rgb(7,45,32));
            text(c, boosting ? "Optimization running..." : (gamingMode ? "Gaming Mode is active" : "Ready to boost"), 42, h-52, 14, Color.rgb(45,235,145), true);

            // Bottom nav
            text(c, "⌂", 48, h-8, 25, Color.rgb(0,185,255), true);
            text(c, "Home", 38, h+10, 11, Color.rgb(0,185,255), true);
            text(c, "Stats", w/2-18, h+10, 11, Color.GRAY, false);
            text(c, "Games", w-105, h+10, 11, Color.GRAY, false);
        }

        void metric(Canvas c, String name, String val, float x, float y) {
            text(c, name, x, y, 10, Color.rgb(115,165,200), true);
            text(c, val, x, y+24, 19, Color.WHITE, true);
        }

        void card(Canvas c, float x, float y, float width, String title, String sub, int accent) {
            rounded(c, x, y, x+width, y+92, 18, Color.rgb(9,23,38));
            text(c, title, x+10, y+34, 12, accent, true);
            text(c, sub, x+10, y+55, 9, Color.rgb(145,175,200), false);
            text(c, "›", x+width-18, y+78, 17, accent, true);
        }

        void game(Canvas c, float x, float y, String name, int accent) {
            rounded(c, x, y, x+125, y+72, 16, Color.rgb(9,23,38));
            text(c, "🎮", x+10, y+31, 18, Color.WHITE, false);
            text(c, name, x+38, y+28, 10, Color.WHITE, true);
            text(c, "● Optimized", x+38, y+49, 9, accent, false);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_UP) {
                float cx = getWidth()/2f, cy = 205;
                float dx = e.getX()-cx, dy=e.getY()-cy;
                if (dx*dx+dy*dy < 150*150) {
                    startBoost();
                    return true;
                }

                // Performance / Gaming Mode card
                float mt = 350;
                float top = mt + 175;
                float gap = 10;
                float cw = (getWidth()-36-gap*3)/4f;
                float left = 18 + cw + gap;
                if (e.getY() >= top && e.getY() <= top+92 &&
                    e.getX() >= left && e.getX() <= left+cw) {
                    toggleGamingMode();
                    return true;
                }
            }
            return true;
        }

        void toggleGamingMode() {
            gamingMode = !gamingMode;
            if (gamingMode) {
                getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                getWindow().getDecorView().setSystemUiVisibility(
                    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    android.view.View.SYSTEM_UI_FLAG_FULLSCREEN |
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                );
                Toast.makeText(MainActivity.this,
                    "Gaming Mode ON • Screen kept awake", Toast.LENGTH_SHORT).show();
            } else {
                getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                getWindow().getDecorView().setSystemUiVisibility(0);
                Toast.makeText(MainActivity.this,
                    "Gaming Mode OFF", Toast.LENGTH_SHORT).show();
            }
            invalidate();
        }

        void startBoost() {
            if (boosting) return;
            boosting = true;
            invalidate();
            Toast.makeText(MainActivity.this, "TomBooster: checking device & network…", Toast.LENGTH_SHORT).show();

            executor.execute(() -> {
                refreshStats();
                refreshPing();
                runOnUiThread(() -> {
                    boosting = false;
                    invalidate();
                    Toast.makeText(MainActivity.this, "Optimization check complete ✓", Toast.LENGTH_SHORT).show();
                });
            });
        }

        void refreshNetwork() {
            executor.execute(() -> {
                refreshStats();
                refreshPing();
                runOnUiThread(this::invalidate);
            });
        }

        void refreshStats() {
            ActivityManagerCompat a = new ActivityManagerCompat(MainActivity.this);
            ram = a.ramPercent();
            cpu = (int)(Math.random()*35)+10; // placeholder until a privileged CPU reader is added
        }

        void refreshPing() {
            try {
                long start = System.currentTimeMillis();
                InetAddress.getByName("1.1.1.1").isReachable(1500);
                ping = (int)(System.currentTimeMillis()-start);
            } catch(Exception ex) { ping = -1; }
        }
    }

    static class ActivityManagerCompat {
        Context c;
        ActivityManagerCompat(Context c){this.c=c;}
        int ramPercent() {
            android.app.ActivityManager am=(android.app.ActivityManager)c.getSystemService(ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi=new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long total=mi.totalMem, avail=mi.availMem;
            if(total<=0) return 0;
            return (int)Math.round((1.0-(double)avail/total)*100);
        }
    }
}
